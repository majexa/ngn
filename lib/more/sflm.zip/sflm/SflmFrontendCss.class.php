<?php

class SflmFrontendCss extends SflmFrontend {}